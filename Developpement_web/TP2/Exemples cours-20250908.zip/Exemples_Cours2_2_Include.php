<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8" />
		<title>Exemple Cours</title>
	</head>
	<body>
		
		<h1>Include </h1>
		<?php 
			include("le_code_a_inclure.php"); 
			// require("le_code_a_inclure.php"); 
			echo "La suite<br />"
		?>
		
		
		
	</body>
</html>