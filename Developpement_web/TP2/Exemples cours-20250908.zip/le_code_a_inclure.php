		<?php
			
			echo '<hr>Je suis dans l\'include<hr/>';
		?>
		
		